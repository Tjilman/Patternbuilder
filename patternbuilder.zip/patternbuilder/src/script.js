const canvas = document.getElementById('patternCanvas');
const widthInput = document.getElementById('canvasWidth');
const heightInput = document.getElementById('canvasHeight');
const detailInput = document.getElementById('detailLevel');
const generateBtn = document.getElementById('generateBtn');
const exportBtn = document.getElementById('exportBtn');

const maxModules = 6;
const colors = ['#FFF100', '#F8F0DD'];

function generatePattern() {
  const width = parseInt(widthInput.value, 10);
  const height = parseInt(heightInput.value, 10);
  const detail = detailInput.value;

  // Reset
  canvas.innerHTML = '';
  canvas.setAttribute('width', width);
  canvas.setAttribute('height', height);

  // Scaling for Preview
  const sidebarWidth = 260;
  const maxViewportWidth = window.innerWidth - sidebarWidth;
  const maxViewportHeight = window.innerHeight;
  let scale = Math.min(maxViewportWidth / width, maxViewportHeight / height, 0.9);
  canvas.style.transform = `scale(${scale})`;

  const shorterSide = Math.min(width, height);
  const gridSize = detail === 'simple' ? shorterSide : (Math.random() > 0.5 ? shorterSide / 2 : shorterSide / 3);

  const cols = Math.ceil(width / gridSize);
  const rows = Math.ceil(height / gridSize);

  const occupied = Array.from({ length: rows }, () => Array(cols).fill(false));

  function placeModule(r, c) {
    if (occupied[r][c]) return false;

    let w = 1;
    let h = 1;

    if (Math.random() > 0.5) {
      if (Math.random() > 0.5 && c + 1 < cols) w = 2;
      else if (r + 1 < rows) h = 2;
    }

    for (let i = 0; i < h; i++) {
      for (let j = 0; j < w; j++) {
        if (occupied[r + i]?.[c + j]) return false;
      }
    }

    for (let i = 0; i < h; i++) {
      for (let j = 0; j < w; j++) {
        occupied[r + i][c + j] = true;
      }
    }

    let moduleWidth = gridSize * w;
    let moduleHeight = gridSize * h;

    if (c + w >= cols) moduleWidth = width - c * gridSize;
    if (r + h >= rows) moduleHeight = height - r * gridSize;

    const x = c * gridSize;
    const y = r * gridSize;

    const color1 = Math.random() > 0.5 ? colors[0] : colors[1];
    const color2 = color1 === colors[0] ? colors[1] : colors[0];

    const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    rect.setAttribute('x', x);
    rect.setAttribute('y', y);
    rect.setAttribute('width', moduleWidth);
    rect.setAttribute('height', moduleHeight);
    rect.setAttribute('fill', color1);
    rect.style.opacity = 0;
    canvas.appendChild(rect);

    const pill = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    pill.setAttribute('x', x);
    pill.setAttribute('y', y);
    pill.setAttribute('width', moduleWidth);
    pill.setAttribute('height', moduleHeight);
    pill.setAttribute('rx', moduleHeight / 2);
    pill.setAttribute('ry', moduleHeight / 2);
    pill.setAttribute('fill', color2);
    pill.style.opacity = 0;
    canvas.appendChild(pill);

    // Fade-in
    setTimeout(() => {
      rect.style.transition = 'opacity 0.5s ease';
      pill.style.transition = 'opacity 0.5s ease';
      rect.style.opacity = 1;
      pill.style.opacity = 1;
    }, Math.random() * 300);

    return true;
  }

  let modulesPlaced = 0;

  outer: for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (modulesPlaced >= maxModules) break outer;
      if (placeModule(r, c)) modulesPlaced++;
    }
  }
}

function exportPattern() {
  const serializer = new XMLSerializer();
  const source = serializer.serializeToString(canvas);
  const blob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = 'pattern.svg';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

generateBtn.addEventListener('click', generatePattern);
exportBtn.addEventListener('click', exportPattern);
window.addEventListener('load', generatePattern);
